describe("Authentication Routes", () => {
  describe("Signup Route", require("./signup"));
  describe("Login Route", require("./login"));
});
